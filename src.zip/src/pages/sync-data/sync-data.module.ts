import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { SyncDataPage } from './sync-data';

@NgModule({
  declarations: [
    SyncDataPage,
  ],
  imports: [
    IonicPageModule.forChild(SyncDataPage),
  ],
})
export class SyncDataPageModule {}
