import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { SessionHelperProvider, AppUtilsProvider } from '../../providers/providers';


/**
 * Generated class for the MainHomePage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@Component({
  selector: 'page-main-home',
  templateUrl: 'main-home.html',
})
export class MainHomePage {

  sliderImages = [];

  constructor(public navCtrl: NavController, public navParams: NavParams, 
               public sessionProvider: SessionHelperProvider, public appUtils: AppUtilsProvider) {


  }

  ionViewDidLoad() {
    
    this.sessionProvider.GetBackImages().then((val)=>{
      this.sliderImages = val.split(',');
      console.log("Slider Array" , this.sliderImages.length);
       
      }).catch(error =>{
        console.log("API ERROR" , error);
      });


    console.log('ionViewDidLoad MainHomePage');
     
    this.appUtils.AddScreenHeader("home" , "Home" , "");

   }

 



}
