import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { MainHomePage } from './main-home';
import { ComponentsModule } from '../../components/components.module';

@NgModule({
  declarations: [
    MainHomePage,
  ],
  imports: [
    IonicPageModule.forChild(MainHomePage),
    ComponentsModule
  ]
  
})
export class MainHomePageModule {}
