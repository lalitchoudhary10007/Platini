import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ApiloginPage } from './apilogin';

@NgModule({
  declarations: [
    ApiloginPage,
  ],
  imports: [
    IonicPageModule.forChild(ApiloginPage),
  ],
})
export class ApiloginPageModule {}
